<script>

</script>

<main>
	<table>
		<tr>
			<td>My cell</td>
		</tr>
	</table>
</main>

<style>
	table {
		border: 1px solid black;
	}
</style>